const btn = document.querySelector('button')
btn.addEventListener('click', () => {
  document.body.textContent = 'Hello World!'
})
