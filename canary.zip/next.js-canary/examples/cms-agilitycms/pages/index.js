import Page, { getStaticProps } from './[...slug]'

export default Page

export { getStaticProps }
