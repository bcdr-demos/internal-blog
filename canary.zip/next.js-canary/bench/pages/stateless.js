import React from 'react'
export default () => <h1>My component!</h1>
